# Vertical Bar Agent

Grounded CrossCheck and Vertical Bar workflows through the production MCP service.

- Vendor: anthropic
- Surface: hosted
- MCP transport: remote-http
- Skills: briefing, deployment, test-suite, stress-test, netsuite-data

Authentication happens through the host connector when a protected tool is used.
