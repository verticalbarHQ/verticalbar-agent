---
name: briefing
description: Produce a Briefing — a self-contained, interactive, on-brand HTML analysis artifact for ANY analysis goal that draws on CrossCheck and/or Vertical Bar data, grounded in real data, and publish it to the in-product Briefing surface. Use whenever an operator wants an analysis / diagnostic / report (over CrossCheck or Vertical Bar sources) they can SEE and trust on the product surface (close health, order-to-cash, AR aging, spend, anomalies, customizations, lineage — any domain). Domain-agnostic on the question; scoped to CrossCheck/Vertical Bar data. NOT tied to month-end close.
---

# Briefing — author & publish an analysis surface

Turn a user's analysis goal into a **self-contained interactive HTML Briefing**, grounded in real data, and publish it to the dashboard's Briefing surface (`/[org]/[ws]/briefings`).

**Domain-agnostic.** A Briefing is the SURFACE + the free-authoring, NOT a fixed report type. The same skill produces a close diagnostic, an order-to-cash process map, an AR-aging view, a spend anomaly brief — whatever the goal is. Do not couple the skill to any one domain.

> The agent owns judgment + visualization; the platform owns only the thin sandboxed render surface (`<iframe sandbox="allow-scripts">`). Quality bar: bespoke visuals by composition, never a templated catalog. Separation: data acquisition/detection is deterministic (every figure traces to a query); authoring is free.

## Method — any analysis, any data

0. **Inspect `whoami`, then resolve authorized scope.** On the hosted remote surface, the MCP
   request already carries verified identity: do not look for `login`, a local browser, a token
   cache, or a window. On an installed local surface, use `login` only when `whoami` reports
   that Cognito identity is absent and the reported runtime supports login. In every case, discover
   workspace scope with `cc_list_workspaces`; no environment value or remembered workspace is authority.
1. **Understand the goal, then CHOOSE the data the question needs.** Acquire it ONLY through CrossCheck's **authenticated, read-only HTTP GET proxies** — the platform runs the read server-side and returns JSON; **the skill never touches a database or NetSuite directly, never holds DB credentials, never issues raw SQL against a database**:
   - the **live NetSuite tools** (`cc_*_netsuite_*`, served by `/api/v1/netsuite-live`) — SuiteQL and other reads over live NetSuite as the user's NetSuite role, for fresh reads;
   - the **landed-data read proxy** (`/api/v1/briefings-data`) — the same shape over CrossCheck's **landed** close event-store (read-only, workspace-scoped; "psql-as-a-GET");
   - CrossCheck read APIs (snapshots / customizations / dependencies / employees) and Vertical Bar process data via their read surfaces.
   All reads ride the existing CrossCheck / Vertical Bar Cognito session. The skill is handed a **thin GET surface, never DB credentials**. The Briefing surface owns authoring + publish, NOT data ownership.
2. **Acquire read-only, coverage-first + ground.** Pull what's actually present for the account; **state gaps honestly** (never silently drop a finding); every figure carries provenance (its source table/query).
3. **Assemble a grounded bundle** = `{ goal, account, generated_at, coverage{available,missing}, facts: {<key>:{value, unit?, provenance}}, series, findings }`.
4. **Free-author a self-contained interactive HTML.** Inject the grounded data inline and read every authoritative figure FROM it — **never free-type a number**. But this is an **internal authoring discipline: NEVER surface the mechanism in the rendered output** — no `window.__BRIEFING_DATA__`, no "references the bundle", no data-block plumbing text. The **only** user-facing provenance is a per-figure **ⓘ tooltip citing the source/detector** (e.g. "Detector B4 — systemnote × employees"); the implementation stays invisible. **Product chrome** (headers, cards, layout, labels) uses CrossCheck `--cc-*` design tokens — no hex on chrome; **data-encoding palettes (chart colors) are free**. **Charts via the vendored viz runtime, auto-inlined.** Put the single marker `<!--BRIEFING_VIZ-->` in `<head>` and author charts against the global `window.d3` (alias `window.BriefingViz`) — a curated, eval-free **d3** toolkit (scales, color, shape, axes, force, drag, zoom, hierarchy, **sankey**). `briefing_publish` splices the ~200KB runtime in at the marker, so you NEVER paste the library yourself; without the marker no runtime is added. A library the runtime lacks may come from an allowed CDN at an exact version (see **What a page may load** below). Use it for flow diagrams (`d3.sankey`); hand-rolled SVG/CSS stays fine for simple KPI/bar. For clean, **non-overlapping flowcharts / decision trees / dependency graphs**, prefer **`briefing_compute_layout`** (give it mermaid text or a generic `{nodes,edges}` model → embed the returned snippet) over hand-rolling `d3.forceSimulation`. Compose freely (KPI grid, charts, tables, process/flow diagrams, findings, honest caveats) — bespoke over a fixed catalog. **Give each figure and finding a reader may point at a stable `data-cc-anchor="<id>"`** (letters, digits, `-`, `_`; keep the same id for the same figure across versions): the viewer can pick an element and comment on it, `screen_get_state` returns the pick with its `key`, and `screen_open` on the `briefing` screen with `highlight` set to a key marks that element in their tab. The dashboard adds its own frame bridge and CSP to every version when it shows it; never add a bridge, `postMessage` code or a CSP of your own.
5. **Self-review (output-blind), then publish — don't screenshot into the chat.** Re-read the assembled HTML against the Acceptance checklist below (every figure cited, ≥1 bespoke visual, no duplicate findings/raw dumps, on-brand `--cc-*` chrome, ≥1 process/flow diagram where the domain has process data) and fix what fails. Do **NOT** spin up headless Chrome / puppeteer to render the artifact to a PNG and surface it in the chat — that is not the deliverable; the published `viewUrl` is where the human sees the real render. A capable installed runtime may open that URL as a best-effort convenience; a hosted runtime returns it for the agent to surface. A pre-publish render is **opt-in only** — reserve it for a layout you have a specific reason to doubt, and even then keep it to yourself.
6. **Publish — the DEFAULT terminal step (opt-out only).** The end of every analysis is `briefing_publish({title, account, html, workspaceId})` → `{ id, viewUrl, rawUrl, workspace }`; do this unless the user explicitly said not to. **When re-publishing an iteration of an earlier analysis, pass a stable `topic` key** (an optional string) so the platform stacks the new artifact as the next *version* of that same topic instead of a fresh, unrelated briefing (RND-3056); an optional `note` can describe what changed in this version. **Pass the SAME `workspaceId` you chose in scope discovery**; no ambient publish scope exists. The result echoes the resolved `workspace` when available — **confirm it is the workspace the goal targeted** before surfacing the link. `viewUrl` is the human dashboard page `/[org]/[ws]/briefings/<id>`; the installed runtime may auto-open it, while a hosted runtime returns it without attempting local UI. `rawUrl` is the auth-gated raw artifact. Surface the `viewUrl` to the user as the deliverable. The artifact carries its own theme (the sandbox can't read the parent's).

### What a page may load

Every surface that shows a Briefing (the dashboard, the raw view, the PDF export) applies the same policy:

- **Scripts** only from `https://cdnjs.cloudflare.com`, `https://cdn.jsdelivr.net/npm/`, `https://unpkg.com`, `https://cdn.tailwindcss.com` and `https://code.jquery.com`. **Always pin an exact version** in the URL (`chart.js@4.4.1`, `/ajax/libs/Chart.js/4.4.1/chart.umd.min.js`), never `@latest`, a major-only tag or no version: a version that changes under a published Briefing changes what it shows.
- **Stylesheets** only from Google Fonts (`https://fonts.googleapis.com`), and **fonts** only from `https://fonts.gstatic.com`.
- **Everything else is blocked**, even on those hosts: no `fetch`/XHR/WebSocket, no image or media from a URL (`<img src="https://…">` does not load), no frames, workers, plugins, forms or `<base>`. Put the data inline. An image or file of your own is attached to the version (see *Files attached to a version*); a small image can also go in as a `data:` URI.
- **Links.** A link to an `https:` URL opens in a new tab when the reader clicks it; other schemes (`javascript:`, `data:`, `http:`) do nothing, and an in-page `#anchor` link scrolls as usual.
- A page that sets no background is shown black on white; set your own background and colours to change that.

### Process map embeds

A Briefing can show a CrossCheck process map in place of a hand-drawn one; the dashboard draws it over the page.

- **Markers.** Where the map goes, put `<div data-cc-embed="process-map" data-cc-id="pm-1"></div>`; give its ref in the html as `<script type="application/json" data-cc-embed-spec="pm-1">{"v":1,"spec":{…}}</script>`, or in `briefing_publish`'s `embeds` as `{ "kind": "process-map", "v": 1, "ccId": "pm-1", "spec": {…} }`. Each `data-cc-id` is unique in the page (letters, digits, `-`, `_`). Optional: `focus` (`{ node: { type, activity } }` or `{ edge: { source, target, source_type, target_type } }`) and `size` (`{ height, chrome: "none" | "compact" }`).
- **The spec is the Process Viewer board.** It is the same canvas a saved board holds. While the user has the Process Viewer open, `screen_get_state` returns it as `state.canvas`: use it as the spec to embed the map they are looking at. If `state.canvas` is null, ask them to open the map in the Process Viewer.
- **Publish snapshots it.** `briefing_publish` checks each ref, that its environment belongs to the workspace and that you may read it, then reads the map once and stores that snapshot with the version. The version always shows that snapshot, whatever the data does later; publish a new version for current numbers.
- **Readers need access.** Each time a reader opens the version, CrossCheck checks that they may read that environment's process data before it serves the snapshot; a reader who may not sees a placeholder instead of the map.
- **Refusals are typed.** A refused publish names its reason as an `EMBED_*` code (for example `EMBED_ENVIRONMENT_FORBIDDEN`, `EMBED_SLOT_MISSING`, `EMBED_PERIOD_NOT_COVERED`); fix what it names and publish again.

### Files attached to a version

A version can carry files: an image the page shows, the CSV behind a chart, a workbook to download. Pass them in `briefing_publish`'s `attachments`; they are bound to that version and listed in the viewer's **Details → Files**.

- **Entries.** `{ name, contentType, data }` sends a new file (`data` is base64). `{ name, from: { version, name? } }` keeps a file an earlier version of the same `topic` carries, without sending it again. `environmentId` (optional) names the environment the file's data came from; a reader then needs that environment's data to open it.
- **Limits.** At most 20 files, 10 MiB each, 25 MiB per version (kept files count). Allowed types: `image/png`, `image/jpeg`, `image/gif`, `image/webp`, `application/pdf`, `text/csv`, `text/plain`, `application/json`, `application/vnd.openxmlformats-officedocument.spreadsheetml.sheet`. No SVG or HTML. The bytes must be what the type says, and the name ends in that type's extension (`.png`, `.jpg`/`.jpeg`, `.gif`, `.webp`, `.pdf`, `.csv`, `.txt`, `.json`, `.xlsx`). You can attach or keep only files whose environment you can read, and a kept file keeps its environment. A refusal names an `ATTACHMENT_*` code.
- **Referencing a file in the html.** Show an image with `<img data-cc-attachment="so-approval.png" alt="…">` (or `src="cc-attachment:so-approval.png"`; also `<source>`, `<video>`, `<audio>`). Link a download with `<a data-cc-attachment="orders.csv">Orders (CSV)</a>`. The dashboard reads the file with the reader's own access and hands it to the page; never inline a file you attached, and never point `src` anywhere else. The PDF, the raw view and the saved HTML file show the page without its attached images (the reader saves the files with **All files**), so put a chart a printed copy needs in the page itself.
- **Data (CSV).** The viewer offers **Share & export → Data (CSV)** only when the version carries `text/csv` files: attach the tables a reader may want to take away.

### Data paths that enrich results (easy to miss)

**Call `briefing_get_schema` FIRST — it is the runtime source of the specific data-path map** (which landed
table, which column, which cross-product join key) for the account you are analyzing. It returns
`{ tables, joinGraph, dataPaths, detectors }`; wire the ones the goal needs (not a prescription). Keep
these path-shaped reminders in mind and let `briefing_get_schema` supply the exact table/column/key names:

- **Actor ids are LANDED — don't default to a name-only join.** Resolve a process actor to a
  CrossCheck employee reference-first (the landed actor/creator keys are in `briefing_get_schema.dataPaths`
  → `actor-identity`); integrations resolve by name via `cc_list_employees`. A live `systemnote` read
  (`cc_run_netsuite_suiteql`) is the narrow fallback ONLY for a not-yet-landed human status-changer.
- **There is a 2nd cross-product bridge beyond the transaction id** — see `briefing_get_schema.joinGraph`.
- **Landed close tables are environment-scoped** — group by environment for multi-env work
  (subsidiary ≠ environment); `briefing_get_schema` gives the exact keying.
- **`$` amounts are coverage-gated** — posting txns carry GL; non-posting Sales Orders have none.
  State the gap; never invent a figure. (`briefing_get_schema.dataPaths` → `amount-coverage`.)
- **Live-read is budget 1/NetSuite-account, fail-closed** — prefer landed data; never parallel-run
  the same account.

## Tools (the current agent MCP)

The installed plugin and hosted remote MCP expose the same workspace-explicit analysis tools. Call
`whoami` instead of inferring which surface is active. **Reads are HTTP proxies the platform
runs server-side; the skill never holds DB/NetSuite credentials and never issues SQL against a
database directly.**

- **`login({ email?, password? })` — installed surfaces only.** If `whoami` reports a local
  surface with no Cognito identity, no args opens browser OAuth; explicit email+password is the Node
  SRP compatibility path. The hosted remote surface has verified request identity and deliberately
  exposes no `login` or `logout`. `whoami` shows current auth, the runtime and workspace routing mode.
- **`briefing_query_data({ sql, limit?, environmentId? })`** — read-only `SELECT`/`WITH` over the platform's landed analytical stores ("psql-as-a-GET"), and the ONLY data-query tool. The platform runs it server-side, workspace-scoped, and returns `{ rows, rowCount, truncated, source }`. WHICH store answers is decided server-side from the relations you name (names via `briefing_get_schema`); a single statement cannot span two stores. Pass `environmentId` when the workspace has more than one and the statement reads process data. **This is NOT a database connection** — it is a guarded read proxy, and a refusal is never an empty result.
- **`cc_run_netsuite_suiteql({ environmentId, query, pageSize?, cursor?, runAs? })`** — read-only SuiteQL `SELECT` against **live** NetSuite, run as a NetSuite role the user may use (the `netsuite-data` skill covers roles, records, saved searches and statements). Use for fresh reads the landed store does not have.
- **`briefing_compute_layout({ mermaid? | model?, opts? })`** → `{ snippet, summary }` — compute a deterministic, **non-overlapping** graph/flow layout at **publish time** (dagre, in Node) and get back a ready-to-embed HTML `snippet` (the artifact ships **no** layout engine — only coordinates + the bundled renderer). Provide EXACTLY ONE of: `mermaid` (flowchart subset — `graph/flowchart TD|LR`; shapes `[] () ([]) {} (())`; edges `--> --- -.-> ==>` + `-->|label|`; chains) OR `model` (generic `{ nodes:[{id,label?,shape?}], edges:[{from,to,label?,style?}] }`). **Data-agnostic** — you map ANY analysis (dependencies, process steps, decision trees, …) into the generic model yourself. For a **swimlane** (lane-banded flow by actor / phase / type — e.g. SYS·AR·AP·ACCT), pass `opts:{layout:'swimlane', lanes:[{id,label?,color?}], laneAxis?:'row'|'col'}` and a `lane` on every node (model-direct; mermaid stays flow-only). Embed the returned `snippet` verbatim in your `<body>` and keep `<!--BRIEFING_VIZ-->` in `<head>`. ELK is reserved and fails loud.
- **`briefing_publish({ title, account?, html, topic?, note?, attachments? })`** → `{ id, viewUrl }` — publish the self-contained artifact to the in-product Briefing surface. Pass a stable `topic` to stack this as the next version of the same topic (RND-3056), and a `note` saying what changed (the list shows it as **What changed**). `attachments` are the version's files (see *Files attached to a version*). `briefing_list` lists published Briefings (metadata only).
- **`cc_*`** — governed CrossCheck tools. The read-only analysis surface includes `cc_list_workspaces`, `cc_list_environments`, `cc_get_process_context`, `cc_get_process_overview`, `cc_list_process_variants`, `cc_list_process_cases`, snapshots, customizations, dependencies, employees, and telemetry. Process tools are scoped by the `environmentId` returned from `cc_list_environments`; legacy Vertical Bar workspace UUIDs are not accepted. The flexible read-only SQL path remains `briefing_query_data`. The narrow deployment-mutation exception is described below.

### Deployment tool pack (RND-2907)

Nine workspace-scoped tools cover the governed deployment walkthrough. Reads:
`cc_list_ci_workflows`, `cc_get_ci_workflow`, `cc_get_env_snapshot_git_source`,
`cc_list_release_packages`, `cc_get_release_package`, `cc_get_ci_workflow_run`. Mutations:
`cc_create_release_package`, `cc_add_release_package_items`, `cc_start_ci_workflow_run`.

All nine use the same routing as the other CrossCheck tools: pass the `workspaceId` returned by
`cc_list_workspaces`. A Cognito user must have the server-authorized scopes for each operation.

Each mutation is a single direct server call — there is no client-side `confirm`/preflight; the
server enforces its own guards and its response (including any error) is surfaced verbatim. Start-run
requires an identified Cognito user. Demo order: establish identity only when `whoami` says the
installed runtime needs it → resolve the snapshot Git source → create package →
add items → get package → start run → poll run. The full start→observe flow (strict
all-target Review, staged A→B) needs PR #833 in the target deployment; before that, start-run
returns `RUN_ENGINE_NOT_READY` (503). Approval is intentionally absent and stays in the web UI.

**Scope discovery — do this FIRST, never hardcode a workspace or environment.** Call
**`cc_list_workspaces`** (and `whoami`) to enumerate the workspaces authorized by the Cognito identity,
then call **`cc_list_environments`** for the selected workspace. Use the sole result automatically at
each step. If more than one is returned and the user's request does not already identify one,
ask the user to choose by safe name; never pick the first or guess. **Thread that returned
`workspaceId` to BOTH every data tool AND `briefing_publish`** — analyze and publish into the same
workspace. No ambient workspace scope exists. Confirm the `workspace` the publish result echoes back
matches the target. A `WORKSPACE_SCOPE_REQUIRED` refusal means perform this discovery and retry the
original tool once. Use **`cc_run_netsuite_suiteql`** (governed, audited, paged, run as the user's
NetSuite role) for live reads; the `cc_*_netsuite_*` tools are the only live-NetSuite path.

**CrossCheck × Vertical Bar (data path, not a prescribed analysis).** The two products mine the **same** NetSuite transactions: CrossCheck carries *state / structure / outcome* (config, close-state, GL, lineage, what changed), Vertical Bar carries *process* (how a transaction flowed — activities, throughput, rework loops). They join on the **NetSuite transaction internalId**, **transaction-scoped** (a period-close event itself has no VB case). **The exact join keys are table-specific and easy to get wrong — get them from `briefing_get_schema.joinGraph`, don't guess** (there is also a 2nd bridge for audit-trail events). Reach the process side two ways: the environment-scoped `cc_get_process_context` / `cc_get_process_overview` / `cc_list_process_variants` / `cc_list_process_cases` tools (use an `environmentId` returned by `cc_list_environments`), or **`briefing_query_data`** = open read-only SQL, which serves the whole process corpus through CrossCheck — the event log, the backbone transaction registry (so you can scope a question to one document type) and the transition relation with per-step durations (for bottlenecks, rework and throughput). It carries *all* transaction object types, not just Sales Order, and those three join to each other in a **single** statement. `briefing_query_data` is the **single** data-query tool: the platform picks which store answers from the relations you name, so a single statement can never span the two stores — run one per store and join the results yourself. Process data is published **per environment**: pass the selected `environmentId`, and treat an explicit refusal as "nothing is published here", **never** as "no process data exists". Coverage is bounded to VB's ingest window (∩ the CrossCheck window); when a join returns 0 rows, distinguish out-of-window from no-relationship. Survey BOTH products in scope discovery before concluding a goal is single-product.

## Example analyses (illustrative — NOT the skill's scope)

The method above is identical for every domain; these are just example detector sets a goal might use:

- **Close health** — period-state lag/blitz, owner-identity-join (systemnote actor × `employees`), task rework, late-JE timing, GL trial-balance; + VB process where relevant.
- **Order-to-cash** — VB process states/variants/durations/bottlenecks (the VB transaction-status field; see `briefing_get_schema`) + CC GL trial-balance.
- **AR aging / spend / anomaly / config-impact / lineage / …** — pick the data + detectors the question demands.

Domain-specific detector queries are **reference content**, never the skill's identity. Add new domains by adding data/detectors, not by forking the skill.

## Acceptance — the human pixel gate (output-blind)

1. every authoritative figure correct + cited — zero "evidence unavailable"; 2. ≥1 bespoke visual a fixed catalog could not express; 3. no duplicate findings / raw dumps; 4. on-brand `--cc-*` chrome; 5. ≥1 data-grounded process/flow diagram where the domain has process data. A prior PoC is a yardstick, never a template (don't copy its composition).
